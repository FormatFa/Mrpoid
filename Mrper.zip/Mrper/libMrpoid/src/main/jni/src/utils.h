#ifndef utils_H__
#define utils_H__

int getFileType(const char *name);
int getFileSize(const char *path);

#endif // utils_H__
