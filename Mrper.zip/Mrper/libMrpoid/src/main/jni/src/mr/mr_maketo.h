/*
** Lua binding: mythroad
** Generated automatically by tolua 5.0a on 12/14/05 15:55:02.
*/

/* Exported function */
TO_MR_API int to_mr_mythroad_open (mrp_State* to_mr_S);

