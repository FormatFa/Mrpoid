/*
  This file is autogenaration from *.mrp. Do not modify it directly.
*/

const unsigned char *mr_m0_files[] =
{mr_m0_file1,NULL
};

