package com.mrpoid.game.keysprite;

/**
 * 具有选择行为的监听器
 * 
 * @author root 2013-09-01
 *
 */
public interface OnChooseLitener {
	public void onChoose(Object object);
	
	public void onCancel();
}
