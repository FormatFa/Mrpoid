package com.mrpoid.apps;

import com.mrpoid.app.EmulatorActivity;

public class AppActivity0 extends EmulatorActivity {
	static {
		APP_ACTIVITY_NAME = "com.mrpoid.apps.AppActivity0";
		APP_SERVICE_NAME = "com.mrpoid.apps.AppService0";
	}
}
