package com.mrpoid.apps;

import com.mrpoid.app.EmulatorActivity;

public class AppActivity3 extends EmulatorActivity {
	static {
		APP_ACTIVITY_NAME = "com.mrpoid.apps.AppActivity3";
		APP_SERVICE_NAME = "com.mrpoid.apps.AppService3";
	}
}
