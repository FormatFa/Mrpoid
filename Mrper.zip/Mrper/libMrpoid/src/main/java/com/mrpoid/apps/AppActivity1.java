package com.mrpoid.apps;

import com.mrpoid.app.EmulatorActivity;

public class AppActivity1 extends EmulatorActivity {
	static {
		APP_ACTIVITY_NAME = "com.mrpoid.apps.AppActivity1";
		APP_SERVICE_NAME = "com.mrpoid.apps.AppService1";
	}
}
