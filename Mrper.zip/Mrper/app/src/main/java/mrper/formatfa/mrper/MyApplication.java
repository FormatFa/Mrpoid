package mrper.formatfa.mrper;

import android.app.Application;


public class MyApplication extends Application {


}
