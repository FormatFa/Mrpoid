package mrper.formatfa.mrper.adapter;

import android.view.View;

public interface OnListClickListener {
     void onItemClick(Object object, View view, int position);


}
