package mrper.formatfa.mrper.adapter;

import android.view.View;

public interface OnListLongClickListener {
    void onItemLongClick(Object obj, View view, int position);
}
